weight_0 = {
    5: {"weight": 0, "max_weight": 1},
    10: {"weight": 0, "max_weight": 1},
    20: {"weight": 0, "max_weight": 1},
    62: {"weight": 0, "max_weight": 1}
}

weight_1 = {
    3: {"weight": 0, "max_weight": 40},
    5: {"weight": 0, "max_weight": 65},
    10: {"weight": 0, "max_weight": 0},
    20: {"weight": 0, "max_weight": 0},
    30: {"weight": 0, "max_weight": 0},
    62: {"weight": 0, "max_weight": 0},
    125: {"weight": 0, "max_weight": 0},
    250: {"weight": 0, "max_weight": 0}
}

weight_2 = {
    3: {"weight": 0, "max_weight": 1},
    5: {"weight": 0, "max_weight": 1},
    10: {"weight": 0, "max_weight": 2},
    20: {"weight": 0, "max_weight": 6},
    62: {"weight": 0, "max_weight": 0},
    125: {"weight": 0, "max_weight": 0},
    250: {"weight": 0, "max_weight": 0}
}

universe1 = [
    'TQQQ',
    'SOXL',
    'FAS',
    'SPXL',
    'UPRO',
    'TECL',
    'TNA',
    'UDOW',
    'UMDD',
    'URTY',
    'EDC',
    'LBJ',
    'RETL',
    'CURE',
    'MIDU',
    'LABU',
    'FNGU',
    'NRGU'
]

universe2 = [
    "TQQQ",
    "UPRO",
    "TNA",
    "FAS",
    "UDOW",
    "SOXL"
]